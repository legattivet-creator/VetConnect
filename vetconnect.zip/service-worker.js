// This service worker is intentionally left blank.
// The notification feature was removed due to platform limitations.
