import type { TFunction } from './i18n';

export const formatAge = (ageInMonths: number, t: TFunction): string => {
  const years = Math.floor(ageInMonths / 12);
  const months = ageInMonths % 12;

  if (years > 0 && months > 0) {
    return t('age.yearsAndMonths', { years, months });
  }
  
  if (years > 0) {
    return years === 1 ? t('age.year', { count: years }) : t('age.years', { count: years });
  }
  
  if (months > 0) {
    return months === 1 ? t('age.month', { count: months }) : t('age.months', { count: months });
  }

  // Handle case for 0 months or less
  return t('age.months', { count: 0 });
};
