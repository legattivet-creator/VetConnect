import React, { useState, createContext, useContext, ReactNode, useCallback } from 'react';
import { CheckCircleIcon, ExclamationCircleIcon, XMarkIcon } from '../components/icons';

type ToastType = 'success' | 'error';

interface ToastMessage {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((message: string, type: ToastType = 'success') => {
    const id = Date.now();
    setToasts(prevToasts => [...prevToasts, { id, message, type }]);
    setTimeout(() => {
      setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, 5000);
  }, []);

  const removeToast = (id: number) => {
    setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 right-4 left-4 sm:left-auto z-50 sm:w-full sm:max-w-xs space-y-2">
        {toasts.map(toast => (
          <Toast key={toast.id} message={toast} onDismiss={removeToast} />
        ))}
      </div>
    </ToastContext.Provider>
  );
};

const toastIcons = {
  success: <CheckCircleIcon className="w-6 h-6 text-sky-500" />,
  error: <ExclamationCircleIcon className="w-6 h-6 text-red-500" />,
};

const toastStyles = {
    success: 'bg-sky-50 border-sky-200',
    error: 'bg-red-50 border-red-200'
}

const Toast: React.FC<{ message: ToastMessage; onDismiss: (id: number) => void }> = ({ message, onDismiss }) => {
  return (
    <div className={`relative flex items-center p-4 w-full rounded-lg shadow-lg border animate-fade-in-down ${toastStyles[message.type]}`}>
      <div className="flex-shrink-0">{toastIcons[message.type]}</div>
      <div className="ml-3 text-sm font-medium text-slate-800">{message.message}</div>
      <button onClick={() => onDismiss(message.id)} className="ml-auto -mx-1.5 -my-1.5 p-1.5 text-slate-400 hover:text-slate-900 rounded-lg focus:ring-2 focus:ring-slate-300 inline-flex h-8 w-8">
        <span className="sr-only">Dismiss</span>
        <XMarkIcon className="w-5 h-5" />
      </button>
      <style>{`
        @keyframes fade-in-down {
            0% {
                opacity: 0;
                transform: translateY(-10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .animate-fade-in-down {
            animation: fade-in-down 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
};