import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define translations
const translations = {
  en: {
    appTitle: 'GlicoPet',
    appTagline: 'Diabetes tracking for your pet.',
    sidebar: {
      footer: '© {{year}} GlicoPet',
    },
    petsView: {
      title: 'My Pets',
      addNewPet: 'Add New Pet',
      addPetFormTitle: 'Add a New Pet',
      namePlaceholder: 'Name',
      agePlaceholder: 'Age',
      colorPlaceholder: 'Color',
      microchipPlaceholder: 'Microchip Number (optional)',
      uploadPhoto: 'Upload Photo',
      photoPreview: 'Photo Preview',
      cancelButton: 'Cancel',
      addPetButton: 'Add Pet',
      noPets: 'No pets registered yet.',
      noPetsHint: 'Click "Add New Pet" to get started.',
      ageUnit: {
          months: 'Months',
          years: 'Years',
      }
    },
    petDetail: {
      backButton: 'Back to My Pets',
      medicalRecord: 'Medical Record',
      weight: 'Weight',
      sex: 'Sex',
      color: 'Color',
      microchip: 'Microchip',
      editPet: 'Edit Pet',
      saveChanges: 'Save Changes',
      changePhoto: 'Change Photo',
      addWeightForm: {
        placeholder: 'Weight (kg)',
        addRecordButton: 'Add Record',
      },
      weightHistory: 'Weight History',
      historyTable: {
        date: 'Date',
        weight: 'Weight',
        actions: 'Actions',
      },
      noWeightRecords: 'No weight records yet.',
      sort: {
        toggle: 'Change sort order',
        asc: 'Ascending',
        desc: 'Descending',
      },
      editButton: 'Edit',
      deleteButton: 'Delete',
      saveButton: 'Save',
      cancelButton: 'Cancel',
      deleteConfirm: 'Are you sure you want to delete this record?',
    },
    weightChart: {
      notEnoughData: 'Not enough data to display a chart.',
    },
    toast: {
        petAdded: '{{name}} was successfully added!',
        petUpdated: "{{name}}'s details were successfully updated!",
        weightAdded: 'Weight record added for {{name}}.',
        weightUpdated: 'Weight record updated for {{name}}.',
        weightDeleted: 'Weight record deleted for {{name}}.',
    },
    species: {
      Dog: 'Dog',
      Cat: 'Cat',
    },
    sex: {
      Male: 'Male',
      Female: 'Female',
    },
    breeds: {
      dog: {
        golden_retriever: 'Golden Retriever',
        labrador_retriever: 'Labrador Retriever',
        french_bulldog: 'French Bulldog',
        beagle: 'Beagle',
        german_shepherd: 'German Shepherd',
        poodle: 'Poodle',
        bulldog: 'Bulldog',
        rottweiler: 'Rottweiler',
        dachshund: 'Dachshund',
        siberian_husky: 'Siberian Husky',
        shih_tzu: 'Shih Tzu',
        yorkshire_terrier: 'Yorkshire Terrier',
        mixed_breed: 'Mixed Breed',
        other: 'Other',
      },
      cat: {
        siamese: 'Siamese',
        persian: 'Persian',
        maine_coon: 'Maine Coon',
        ragdoll: 'Ragdoll',
        bengal: 'Bengal',
        sphynx: 'Sphynx',
        british_shorthair: 'British Shorthair',
        abyssinian: 'Abyssinian',
        american_shorthair: 'American Shorthair',
        scottish_fold: 'Scottish Fold',
        himalayan: 'Himalayan',
        norwegian_forest: 'Norwegian Forest',
        mixed_breed: 'Mixed Breed',
        other: 'Other',
      }
    },
    age: {
      month: '{{count}} month old',
      months: '{{count}} months old',
      year: '{{count}} year old',
      years: '{{count}} years old',
      yearsAndMonths: '{{years}} y, {{months}} m old',
    },
  },
  pt: {
    appTitle: 'GlicoPet',
    appTagline: 'O registro de diabetes para seu pet.',
    sidebar: {
      footer: '© {{year}} GlicoPet',
    },
    petsView: {
      title: 'Meus Pets',
      addNewPet: 'Adicionar Novo Pet',
      addPetFormTitle: 'Adicionar um Novo Pet',
      namePlaceholder: 'Nome',
      agePlaceholder: 'Idade',
      colorPlaceholder: 'Cor',
      microchipPlaceholder: 'Número do Microchip (opcional)',
      uploadPhoto: 'Carregar Foto',
      photoPreview: 'Pré-visualização',
      cancelButton: 'Cancelar',
      addPetButton: 'Adicionar Pet',
      noPets: 'Nenhum pet registrado ainda.',
      noPetsHint: 'Clique em "Adicionar Novo Pet" para começar.',
      ageUnit: {
          months: 'Meses',
          years: 'Anos',
      }
    },
    petDetail: {
      backButton: 'Voltar para Meus Pets',
      medicalRecord: 'Prontuário',
      weight: 'Peso',
      sex: 'Sexo',
      color: 'Cor',
      microchip: 'Microchip',
      editPet: 'Editar Pet',
      saveChanges: 'Salvar Alterações',
      changePhoto: 'Alterar Foto',
      addWeightForm: {
        placeholder: 'Peso (kg)',
        addRecordButton: 'Adicionar Registro',
      },
      weightHistory: 'Histórico de Peso',
      historyTable: {
        date: 'Data',
        weight: 'Peso',
        actions: 'Ações',
      },
      noWeightRecords: 'Nenhum registro de peso ainda.',
      sort: {
        toggle: 'Alterar ordem',
        asc: 'Crescente',
        desc: 'Decrescente',
      },
      editButton: 'Editar',
      deleteButton: 'Excluir',
      saveButton: 'Salvar',
      cancelButton: 'Cancelar',
      deleteConfirm: 'Tem certeza de que deseja excluir este registro?',
    },
    weightChart: {
      notEnoughData: 'Dados insuficientes para exibir um gráfico.',
    },
    toast: {
        petAdded: '{{name}} foi adicionado com sucesso!',
        petUpdated: 'Dados de {{name}} atualizados com sucesso!',
        weightAdded: 'Registro de peso adicionado para {{name}}.',
        weightUpdated: 'Registro de peso atualizado para {{name}}.',
        weightDeleted: 'Registro de peso excluído para {{name}}.',
    },
    species: {
      Dog: 'Cachorro',
      Cat: 'Gato',
    },
    sex: {
      Male: 'Macho',
      Female: 'Fêmea',
    },
    breeds: {
      dog: {
        golden_retriever: 'Golden Retriever',
        labrador_retriever: 'Labrador Retriever',
        french_bulldog: 'Buldogue Francês',
        beagle: 'Beagle',
        german_shepherd: 'Pastor Alemão',
        poodle: 'Poodle',
        bulldog: 'Buldogue',
        rottweiler: 'Rottweiler',
        dachshund: 'Dachshund (Salsicha)',
        siberian_husky: 'Husky Siberiano',
        shih_tzu: 'Shih Tzu',
        yorkshire_terrier: 'Yorkshire Terrier',
        mixed_breed: 'SRD (Vira-lata)',
        other: 'Outra',
      },
      cat: {
        siamese: 'Siamês',
        persian: 'Persa',
        maine_coon: 'Maine Coon',
        ragdoll: 'Ragdoll',
        bengal: 'Bengal',
        sphynx: 'Sphynx',
        british_shorthair: 'Pelo Curto Inglês',
        abyssinian: 'Abissínio',
        american_shorthair: 'Pelo Curto Americano',
        scottish_fold: 'Scottish Fold',
        himalayan: 'Himalaia',
        norwegian_forest: 'Norueguês da Floresta',
        mixed_breed: 'SRD (Vira-lata)',
        other: 'Outra',
      }
    },
    age: {
      month: '{{count}} mês',
      months: '{{count}} meses',
      year: '{{count}} ano',
      years: '{{count}} anos',
      yearsAndMonths: '{{years}} a, {{months}} m',
    },
  },
};

type Language = 'en' | 'pt';
export type TFunction = (key: string, replacements?: { [key: string]: string | number }) => string;

// Helper to safely access nested properties
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getNested(obj: any, path: string): string | undefined {
    return path.split('.').reduce((acc, part) => acc && acc[part], obj);
}


interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: TFunction;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('pt');

  const t: TFunction = (key, replacements) => {
    const translationSet = translations[language];
    let text = getNested(translationSet, key) || key;

    if (replacements) {
        Object.keys(replacements).forEach(rKey => {
            text = text.replace(`{{${rKey}}}`, String(replacements[rKey]));
        });
    }

    return text;
  };

  // FIX: Using JSX in a .ts file causes parsing errors. Replaced with React.createElement.
  return React.createElement(LanguageContext.Provider, { value: { language, setLanguage, t } }, children);
};

export const useTranslations = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslations must be used within a LanguageProvider');
  }
  return context;
};