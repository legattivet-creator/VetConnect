export type PetSpecies = 'Dog' | 'Cat';

export interface WeightRecord {
  id: number;
  date: string;
  weight: number;
}

export interface Pet {
  id: number;
  name: string;
  species: PetSpecies;
  breed: string; // breed key
  age: number; // in months
  sex: 'Male' | 'Female';
  color: string;
  microchip: string;
  imageUrl: string;
  weightRecords: WeightRecord[];
}

export type View = 'pets' | 'petDetail';