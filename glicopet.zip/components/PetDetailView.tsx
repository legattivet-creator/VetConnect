import React, { useState, useEffect } from 'react';
import type { Pet, WeightRecord, PetSpecies } from '../types';
import { ArrowLeftIcon, WeightIcon, ChartBarIcon, ArrowsUpDownIcon, PencilIcon, TrashIcon, CheckIcon, XMarkIcon, SpinnerIcon, PhotoIcon } from './icons';
import WeightChart from './WeightChart';
import { useTranslations } from '../lib/i18n';
import { formatAge } from '../lib/formatters';
import { dogBreedKeys, catBreedKeys } from '../lib/breeds';

type PetFormData = Omit<Pet, 'id' | 'weightRecords' | 'age'> & { age: string; ageUnit: 'months' | 'years' };

interface PetDetailViewProps {
  pet: Pet;
  onBack: () => void;
  onUpdatePet: (petId: number, data: Omit<Pet, 'id' | 'weightRecords' | 'age'> & { age: number }) => Promise<void>;
  onAddWeight: (petId: number, record: Omit<WeightRecord, 'id'>) => Promise<void>;
  onUpdateWeight: (petId: number, recordId: number, updatedData: { date: string, weight: number }) => Promise<void>;
  onDeleteWeight: (petId: number, recordId: number) => Promise<void>;
}

const AddWeightForm: React.FC<{ petId: number, onAddWeight: PetDetailViewProps['onAddWeight'] }> = ({ petId, onAddWeight }) => {
    const { t } = useTranslations();
    const [weight, setWeight] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (weight && date && !isLoading) {
            setIsLoading(true);
            await onAddWeight(petId, { date, weight: parseFloat(weight) });
            setIsLoading(false);
            setWeight('');
        }
    }

    return (
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-2 p-4 bg-slate-100 rounded-lg mt-4">
            <input 
                type="date" 
                value={date}
                onChange={e => setDate(e.target.value)}
                className="p-2 border rounded-lg w-full sm:w-auto"
                required 
            />
            <input 
                type="number" 
                step="0.1"
                placeholder={t('petDetail.addWeightForm.placeholder')} 
                value={weight}
                onChange={e => setWeight(e.target.value)}
                className="p-2 border rounded-lg w-full sm:w-auto"
                required 
            />
            <button type="submit" className="w-full sm:w-40 px-4 py-2 bg-sky-500 text-white rounded-lg hover:bg-sky-600 font-semibold flex items-center justify-center" disabled={isLoading}>
                {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : t('petDetail.addWeightForm.addRecordButton')}
            </button>
        </form>
    )
}

const PetEditForm: React.FC<{ pet: Pet, onSave: PetDetailViewProps['onUpdatePet'], onCancel: () => void }> = ({ pet, onSave, onCancel }) => {
    const { t } = useTranslations();
    const [formData, setFormData] = useState<PetFormData>({
        name: pet.name,
        species: pet.species,
        breed: pet.breed,
        sex: pet.sex,
        color: pet.color,
        microchip: pet.microchip,
        imageUrl: pet.imageUrl,
        age: (pet.age / 12).toFixed(1),
        ageUnit: 'years'
    });
    const [imagePreview, setImagePreview] = useState<string>(pet.imageUrl);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (formData.species === 'Dog' && !dogBreedKeys.includes(formData.breed)) {
          setFormData(d => ({ ...d, breed: dogBreedKeys[0] }));
        } else if (formData.species === 'Cat' && !catBreedKeys.includes(formData.breed)) {
          setFormData(d => ({ ...d, breed: catBreedKeys[0] }));
        }
      }, [formData.species, formData.breed]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                setImagePreview(result);
                setFormData(prev => ({ ...prev, imageUrl: result }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        const ageInMonths = formData.ageUnit === 'years' ? parseFloat(formData.age) * 12 : parseInt(formData.age, 10);
        await onSave(pet.id, { ...formData, age: ageInMonths });
        setIsLoading(false);
    };

    return (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-3 flex flex-col items-center gap-4">
                <img src={imagePreview} alt={formData.name} className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-4 border-sky-200" />
                 <label htmlFor="photo-edit" className="cursor-pointer px-3 py-1.5 text-sm bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 font-semibold">
                    {t('petDetail.changePhoto')}
                </label>
                <input id="photo-edit" type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
            </div>

            <input type="text" name="name" placeholder={t('petsView.namePlaceholder')} value={formData.name} onChange={handleChange} className="p-2 border rounded-lg w-full" required />
            <select name="species" value={formData.species} onChange={handleChange} className="p-2 border rounded-lg w-full" required>
                <option value="Dog">{t('species.Dog')}</option>
                <option value="Cat">{t('species.Cat')}</option>
            </select>
            <select name="breed" value={formData.breed} onChange={handleChange} className="p-2 border rounded-lg w-full" required>
                {(formData.species === 'Dog' ? dogBreedKeys : catBreedKeys).map(b => (
                    <option key={b} value={b}>{t(`breeds.${formData.species.toLowerCase()}.${b}`)}</option>
                ))}
            </select>
            <div className="grid grid-cols-2 gap-2">
                <input type="number" name="age" placeholder={t('petsView.agePlaceholder')} value={formData.age} onChange={handleChange} className="p-2 border rounded-lg w-full" required min="0" />
                <select name="ageUnit" value={formData.ageUnit} onChange={handleChange} className="p-2 border rounded-lg w-full" required>
                    <option value="years">{t('petsView.ageUnit.years')}</option>
                    <option value="months">{t('petsView.ageUnit.months')}</option>
                </select>
            </div>
            <select name="sex" value={formData.sex} onChange={handleChange} className="p-2 border rounded-lg w-full" required>
                <option value="Male">{t('sex.Male')}</option>
                <option value="Female">{t('sex.Female')}</option>
            </select>
            <input type="text" name="color" placeholder={t('petsView.colorPlaceholder')} value={formData.color} onChange={handleChange} className="p-2 border rounded-lg w-full" required />
            <div className="md:col-span-3">
                <input type="text" name="microchip" placeholder={t('petsView.microchipPlaceholder')} value={formData.microchip} onChange={handleChange} className="p-2 border rounded-lg w-full" />
            </div>
            <div className="md:col-span-3 flex justify-end space-x-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300">{t('petDetail.cancelButton')}</button>
                <button type="submit" className="px-4 py-2 bg-sky-500 text-white rounded-lg hover:bg-sky-600 flex items-center justify-center w-36" disabled={isLoading}>
                    {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : t('petDetail.saveChanges')}
                </button>
            </div>
        </form>
    );
};

const PetDetailView: React.FC<PetDetailViewProps> = ({ pet, onBack, onUpdatePet, onAddWeight, onUpdateWeight, onDeleteWeight }) => {
  const { t, language } = useTranslations();
  const [listSortOrder, setListSortOrder] = useState<'asc' | 'desc'>('desc');
  const [editingRecordId, setEditingRecordId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<{ date: string, weight: string }>({ date: '', weight: '' });
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState<number | null>(null);
  const [isEditingPet, setIsEditingPet] = useState(false);
  
  const locale = language === 'pt' ? 'pt-BR' : 'en-US';

  const handleSavePet = async (petId: number, data: Omit<Pet, 'id' | 'weightRecords' | 'age'> & { age: number }) => {
    await onUpdatePet(petId, data);
    setIsEditingPet(false);
  };

  const handleToggleSort = () => {
    setListSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  }

  const handleStartEdit = (record: WeightRecord) => {
    setEditingRecordId(record.id);
    setEditFormData({ date: record.date, weight: record.weight.toString() });
  };

  const handleCancelEdit = () => {
    setEditingRecordId(null);
  };

  const handleSaveEdit = async () => {
    if (editingRecordId && editFormData.weight && editFormData.date && !isSaving) {
        setIsSaving(true);
        await onUpdateWeight(pet.id, editingRecordId, { 
            date: editFormData.date, 
            weight: parseFloat(editFormData.weight) 
        });
        setIsSaving(false);
        setEditingRecordId(null);
    }
  };

  const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditFormData({
        ...editFormData,
        [e.target.name]: e.target.value
    });
  };
  
  const handleDelete = async (recordId: number) => {
    if (window.confirm(t('petDetail.deleteConfirm'))) {
        setIsDeleting(recordId);
        await onDeleteWeight(pet.id, recordId);
        setIsDeleting(null);
    }
  };

  const chronologicallySortedData = [...pet.weightRecords].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const displayData = listSortOrder === 'asc' ? chronologicallySortedData : [...chronologicallySortedData].reverse();

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center text-sky-600 hover:text-sky-800 font-semibold">
        <ArrowLeftIcon className="w-5 h-5 mr-2" />
        {t('petDetail.backButton')}
      </button>

      {isEditingPet ? (
        <PetEditForm pet={pet} onSave={handleSavePet} onCancel={() => setIsEditingPet(false)} />
      ) : (
        <div className="bg-white p-6 rounded-xl shadow-lg flex flex-col md:flex-row items-center gap-6">
            <img src={pet.imageUrl} alt={pet.name} className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-4 border-sky-200" />
            <div className="flex-1 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-4">
                    <h2 className="text-3xl sm:text-4xl font-bold text-slate-800">{pet.name}</h2>
                    <button onClick={() => setIsEditingPet(true)} title={t('petDetail.editPet')} className="p-2 rounded-full text-slate-500 hover:bg-slate-200 hover:text-sky-600 transition-colors">
                        <PencilIcon className="w-5 h-5" />
                    </button>
                </div>
                <p className="text-slate-500 text-lg">{t(`breeds.${pet.species.toLowerCase()}.${pet.breed}`)}</p>
                <div className="mt-4 flex flex-wrap justify-center md:justify-start gap-2 text-sm">
                    <span className={`inline-flex items-center px-3 py-1 text-sm font-semibold rounded-full ${pet.species === 'Dog' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                        {t(`species.${pet.species}`)} - {formatAge(pet.age, t)}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full font-semibold bg-slate-100 text-slate-700">
                        <strong className="mr-1.5">{t('petDetail.sex')}:</strong> {t(`sex.${pet.sex}`)}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full font-semibold bg-slate-100 text-slate-700">
                        <strong className="mr-1.5">{t('petDetail.color')}:</strong> {pet.color}
                    </span>
                    {pet.microchip && (
                        <span className="inline-flex items-center px-3 py-1 rounded-full font-semibold bg-slate-100 text-slate-700">
                            <strong className="mr-1.5">{t('petDetail.microchip')}:</strong> {pet.microchip}
                        </span>
                    )}
                </div>
            </div>
        </div>
      )}


      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-2xl font-bold text-slate-800 border-b pb-2 mb-4">{t('petDetail.medicalRecord')}</h3>
        <div className="space-y-4">
          <h4 className="flex items-center text-xl font-semibold text-slate-700">
            <WeightIcon className="w-6 h-6 mr-2 text-sky-600" />
            {t('petDetail.weight')}
          </h4>
          <AddWeightForm petId={pet.id} onAddWeight={onAddWeight} />
          <div className="mt-6">
            <h5 className="flex items-center text-lg font-semibold text-slate-600 mb-2">
                <ChartBarIcon className="w-5 h-5 mr-2" />
                {t('petDetail.weightHistory')}
                {pet.weightRecords.length > 1 && (
                  <button onClick={handleToggleSort} className="ml-auto p-1 rounded-full hover:bg-slate-200 transition-colors" aria-label={t('petDetail.sort.toggle')} title={t('petDetail.sort.toggle')}>
                      <ArrowsUpDownIcon className="w-5 h-5 text-slate-500" />
                  </button>
                )}
            </h5>
            {pet.weightRecords.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div className="p-4 bg-slate-50 rounded-lg lg:col-span-2">
                       <WeightChart data={displayData} />
                    </div>
                    <div className="max-h-96 overflow-y-auto relative">
                       <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-slate-700 uppercase bg-slate-100 sticky top-0 z-10">
                                <tr>
                                    <th scope="col" className="px-4 py-2">{t('petDetail.historyTable.date')}</th>
                                    <th scope="col" className="px-4 py-2 text-right">{t('petDetail.historyTable.weight')}</th>
                                    <th scope="col" className="px-4 py-2 text-center">{t('petDetail.historyTable.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {displayData.map(record => (
                                    <tr key={record.id} className={`border-b border-slate-100 ${editingRecordId === record.id ? 'bg-sky-50' : 'bg-white hover:bg-slate-50'}`}>
                                    {editingRecordId === record.id ? (
                                        <>
                                            <td className="p-1">
                                                <input type="date" name="date" value={editFormData.date} onChange={handleEditFormChange} className="p-1 border rounded-md w-full bg-white text-sm" />
                                            </td>
                                            <td className="p-1">
                                                <div className="flex items-center justify-end">
                                                    <input type="number" name="weight" step="0.1" value={editFormData.weight} onChange={handleEditFormChange} className="p-1 border rounded-md w-20 bg-white text-sm text-right" />
                                                </div>
                                            </td>
                                            <td className="p-1">
                                                <div className="flex items-center justify-center space-x-1">
                                                    <button onClick={handleSaveEdit} title={t('petDetail.saveButton')} className="p-1 text-sky-600 hover:text-sky-800" disabled={isSaving}>
                                                      {isSaving ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : <CheckIcon className="w-5 h-5"/>}
                                                    </button>
                                                    <button onClick={handleCancelEdit} title={t('petDetail.cancelButton')} className="p-1 text-slate-500 hover:text-slate-700"><XMarkIcon className="w-5 h-5"/></button>
                                                </div>
                                            </td>
                                        </>
                                    ) : (
                                        <>
                                            <td className="px-4 py-2 font-medium text-slate-800 whitespace-nowrap">
                                                {new Date(record.date).toLocaleDateString(locale, { year: 'numeric', month: 'short', day: 'numeric' })}
                                            </td>
                                            <td className="px-4 py-2 text-right font-semibold text-slate-700">
                                                {record.weight.toFixed(1)} kg
                                            </td>
                                            <td className="px-4 py-2">
                                                <div className="flex items-center justify-center space-x-1">
                                                    <button onClick={() => handleStartEdit(record)} title={t('petDetail.editButton')} className="p-1 text-slate-500 hover:text-blue-600"><PencilIcon className="w-4 h-4" /></button>
                                                    <button onClick={() => handleDelete(record.id)} title={t('petDetail.deleteButton')} className="p-1 text-slate-500 hover:text-red-600" disabled={isDeleting === record.id}>
                                                      {isDeleting === record.id ? <SpinnerIcon className="w-4 h-4 animate-spin" /> : <TrashIcon className="w-4 h-4" />}
                                                    </button>
                                                </div>
                                            </td>
                                        </>
                                    )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            ) : (
                <p className="text-slate-500 text-center py-4">{t('petDetail.noWeightRecords')}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PetDetailView;