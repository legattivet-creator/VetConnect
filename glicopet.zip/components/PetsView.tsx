import React, { useState, useEffect } from 'react';
import type { Pet, PetSpecies } from '../types';
import { useTranslations } from '../lib/i18n';
import { dogBreedKeys, catBreedKeys } from '../lib/breeds';
import { formatAge } from '../lib/formatters';
import { SpinnerIcon, PhotoIcon } from './icons';


interface PetsViewProps {
  pets: Pet[];
  addPet: (pet: Omit<Pet, 'id' | 'weightRecords'>) => Promise<void>;
  onSelectPet: (petId: number) => void;
}

const PetCard: React.FC<{ pet: Pet; onSelect: () => void }> = ({ pet, onSelect }) => {
    const { t } = useTranslations();
    return (
        <button onClick={onSelect} className="bg-white rounded-xl shadow-md overflow-hidden text-center transition-all duration-300 hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 w-full">
            <img src={pet.imageUrl} alt={pet.name} className="w-full h-48 object-cover" />
            <div className="p-4">
            <h3 className="text-xl font-bold text-slate-800">{pet.name}</h3>
            <p className="text-slate-500">{t(`breeds.${pet.species.toLowerCase()}.${pet.breed}`)}</p>
            <span className={`mt-2 inline-block px-3 py-1 text-xs font-semibold rounded-full ${
                pet.species === 'Dog' ? 'bg-blue-100 text-blue-800' : 
                pet.species === 'Cat' ? 'bg-purple-100 text-purple-800' :
                'bg-gray-100 text-gray-800'
            }`}>
                {t(`species.${pet.species}`)} - {formatAge(pet.age, t)}
            </span>
            </div>
        </button>
    );
}

const AddPetForm: React.FC<{ addPet: PetsViewProps['addPet'], onCancel: () => void }> = ({ addPet, onCancel }) => {
  const { t } = useTranslations();
  const [name, setName] = useState('');
  const [species, setSpecies] = useState<PetSpecies>('Dog');
  const [breed, setBreed] = useState(dogBreedKeys[0]);
  const [age, setAge] = useState('');
  const [ageUnit, setAgeUnit] = useState<'months' | 'years'>('years');
  const [sex, setSex] = useState<'Male' | 'Female'>('Male');
  const [color, setColor] = useState('');
  const [microchip, setMicrochip] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (species === 'Dog') {
      setBreed(dogBreedKeys[0]);
    } else {
      setBreed(catBreedKeys[0]);
    }
  }, [species]);
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            setImagePreview(reader.result as string);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (name && species && breed && age && !isLoading) {
      setIsLoading(true);
      const ageInMonths = ageUnit === 'years' ? parseInt(age, 10) * 12 : parseInt(age, 10);
      await addPet({ 
        name, 
        species, 
        breed, 
        age: ageInMonths,
        sex,
        color,
        microchip,
        imageUrl: imagePreview || `https://picsum.photos/seed/${name.toLowerCase()}/200`
      });
      setIsLoading(false);
      onCancel(); // Close form after adding
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-4">{t('petsView.addPetFormTitle')}</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="text" placeholder={t('petsView.namePlaceholder')} value={name} onChange={e => setName(e.target.value)} className="p-2 border rounded-lg w-full" required />
        <select value={species} onChange={e => setSpecies(e.target.value as PetSpecies)} className="p-2 border rounded-lg w-full" required>
          <option value="Dog">{t('species.Dog')}</option>
          <option value="Cat">{t('species.Cat')}</option>
        </select>
        <select value={breed} onChange={e => setBreed(e.target.value)} className="p-2 border rounded-lg w-full" required>
          {(species === 'Dog' ? dogBreedKeys : catBreedKeys).map(b => (
            <option key={b} value={b}>{t(`breeds.${species.toLowerCase()}.${b}`)}</option>
          ))}
        </select>
        <div className="grid grid-cols-2 gap-2">
            <input type="number" placeholder={t('petsView.agePlaceholder')} value={age} onChange={e => setAge(e.target.value)} className="p-2 border rounded-lg w-full" required min="0" />
            <select value={ageUnit} onChange={e => setAgeUnit(e.target.value as 'months' | 'years')} className="p-2 border rounded-lg w-full" required>
                <option value="years">{t('petsView.ageUnit.years')}</option>
                <option value="months">{t('petsView.ageUnit.months')}</option>
            </select>
        </div>
        <select value={sex} onChange={e => setSex(e.target.value as 'Male' | 'Female')} className="p-2 border rounded-lg w-full" required>
            <option value="Male">{t('sex.Male')}</option>
            <option value="Female">{t('sex.Female')}</option>
        </select>
        <input type="text" placeholder={t('petsView.colorPlaceholder')} value={color} onChange={e => setColor(e.target.value)} className="p-2 border rounded-lg w-full" required />
        <div className="md:col-span-3">
          <input type="text" placeholder={t('petsView.microchipPlaceholder')} value={microchip} onChange={e => setMicrochip(e.target.value)} className="p-2 border rounded-lg w-full" />
        </div>
        <div className="md:col-span-3 flex flex-col items-center gap-4 border-t pt-4">
            <div className="flex items-center gap-4">
                {imagePreview ? (
                     <img src={imagePreview} alt={t('petsView.photoPreview')} className="w-24 h-24 rounded-full object-cover border-2 border-slate-200" />
                ) : (
                    <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                        <PhotoIcon className="w-10 h-10" />
                    </div>
                )}
                <label htmlFor="photo-upload" className="cursor-pointer px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 font-semibold">
                    {t('petsView.uploadPhoto')}
                </label>
                <input id="photo-upload" type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
            </div>
        </div>
        <div className="md:col-span-3 flex justify-end space-x-2">
          <button type="button" onClick={onCancel} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300">{t('petsView.cancelButton')}</button>
          <button type="submit" className="px-4 py-2 bg-sky-500 text-white rounded-lg hover:bg-sky-600 flex items-center justify-center w-28" disabled={isLoading}>
            {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin" /> : t('petsView.addPetButton')}
          </button>
        </div>
      </form>
    </div>
  );
};


const PetsView: React.FC<PetsViewProps> = ({ pets, addPet, onSelectPet }) => {
    const { t } = useTranslations();
    const [showForm, setShowForm] = useState(false);

    return (
        <div className="space-y-8">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">{t('petsView.title')}</h2>
                {!showForm && (
                    <button onClick={() => setShowForm(true)} className="px-4 py-2 bg-sky-500 text-white rounded-lg hover:bg-sky-600 font-semibold shadow-sm hover:shadow-md transition-shadow w-full sm:w-auto">
                        {t('petsView.addNewPet')}
                    </button>
                )}
            </div>
            
            {showForm && <AddPetForm addPet={addPet} onCancel={() => setShowForm(false)} />}
            
            {pets.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {pets.map(pet => <PetCard key={pet.id} pet={pet} onSelect={() => onSelectPet(pet.id)} />)}
                </div>
            ) : (
                <div className="text-center py-10 bg-white rounded-xl shadow-md">
                    <p className="text-slate-500">{t('petsView.noPets')}</p>
                    <p className="text-slate-400 text-sm mt-2">{t('petsView.noPetsHint')}</p>
                </div>
            )}
        </div>
    );
};

export default PetsView;