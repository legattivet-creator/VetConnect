import React from 'react';
import type { WeightRecord } from '../types';
import { useTranslations } from '../lib/i18n';

interface WeightChartProps {
  data: WeightRecord[];
}

const WeightChart: React.FC<WeightChartProps> = ({ data }) => {
  const { t, language } = useTranslations();
  const locale = language === 'pt' ? 'pt-BR' : 'en-US';
  
  if (data.length < 2) {
    return <div className="flex items-center justify-center h-64 text-slate-500">{t('weightChart.notEnoughData')}</div>;
  }

  const width = 500;
  const height = 250;
  const margin = { top: 20, right: 20, bottom: 40, left: 40 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  // Create a chronologically sorted copy for calculating scales, regardless of display order
  const sortedDataForScale = [...data].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const weights = sortedDataForScale.map(d => d.weight);
  const minWeight = Math.min(...weights);
  const maxWeight = Math.max(...weights);
  
  // Add a little padding to the Y axis
  const yMin = Math.max(0, minWeight - (maxWeight - minWeight) * 0.1);
  const yMax = maxWeight + (maxWeight - minWeight) * 0.1;

  const xScale = (index: number) => (index / (data.length - 1)) * innerWidth;
  const yScale = (weight: number) => innerHeight - ((weight - yMin) / (yMax - yMin)) * innerHeight;

  const pathData = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i)} ${yScale(d.weight)}`).join(' ');

  const yAxisTicks = 5;
  const yTicks = Array.from({ length: yAxisTicks }, (_, i) => {
      const value = yMin + (i / (yAxisTicks - 1)) * (yMax - yMin);
      return { value, y: yScale(value) };
  });

  // Determine which x-axis labels to show
  const indicesToShow = new Set<number>();
  if (data.length <= 5) {
      data.forEach((_, i) => indicesToShow.add(i));
  } else {
      indicesToShow.add(0); // First
      indicesToShow.add(data.length - 1); // Last
      const numMiddleLabels = 3;
      const step = (data.length - 1) / (numMiddleLabels + 1);
      for (let i = 1; i <= numMiddleLabels; i++) {
          indicesToShow.add(Math.round(i * step));
      }
  }


  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto" aria-label="Weight history chart">
      <g transform={`translate(${margin.left}, ${margin.top})`}>
        {/* Y Axis */}
        <g aria-hidden="true">
            <line x1={0} y1={0} x2={0} y2={innerHeight} stroke="#d1d5db" />
            {yTicks.map(tick => (
            <g key={tick.value} transform={`translate(0, ${tick.y})`}>
                <line x1={-5} y1={0} x2={0} y2={0} stroke="#9ca3af" />
                <text x={-8} y={4} textAnchor="end" fontSize="10" fill="#6b7280">
                {tick.value.toFixed(1)}
                </text>
            </g>
            ))}
        </g>
        
        {/* X Axis */}
        <g aria-hidden="true">
            <line x1={0} y1={innerHeight} x2={innerWidth} y2={innerHeight} stroke="#d1d5db" />
            {data.map((d, i) => (
            <g key={d.id} transform={`translate(${xScale(i)}, ${innerHeight})`}>
                <line y1={0} y2={5} stroke="#9ca3af" />
                {indicesToShow.has(i) && (
                    <text y={20} textAnchor="middle" fontSize="10" fill="#6b7280">
                        {new Date(d.date).toLocaleDateString(locale, { month: 'short', day: 'numeric' })}
                    </text>
                )}
            </g>
            ))}
        </g>

        {/* Line */}
        <path d={pathData} fill="none" stroke="#0ea5e9" strokeWidth="2" />

        {/* Points */}
        {data.map((d, i) => (
          <circle key={d.id} cx={xScale(i)} cy={yScale(d.weight)} r="3" fill="#0ea5e9" />
        ))}
      </g>
    </svg>
  );
};

export default WeightChart;