import React from 'react';
import { useTranslations } from '../lib/i18n';

const Sidebar: React.FC = () => {
  const { t } = useTranslations();
  return (
    <aside className="hidden lg:flex w-64 bg-white flex-shrink-0 border-r border-slate-200 p-4 flex-col">
      {/* Navigation item removed for a cleaner UI */}
      <div className="mt-auto text-center text-slate-500 text-xs">
        <p>{t('sidebar.footer', { year: new Date().getFullYear() })}</p>
      </div>
    </aside>
  );
};

export default Sidebar;