import React, { useState, useCallback } from 'react';
import type { View, Pet, WeightRecord } from './types';
import Sidebar from './components/Sidebar';
import PetsView from './components/PetsView';
import PetDetailView from './components/PetDetailView';
import { PetPawIcon } from './components/icons';
import { LanguageProvider, useTranslations } from './lib/i18n';
import { ToastProvider, useToast } from './lib/toast';

const LanguageSwitcher = () => {
  const { language, setLanguage } = useTranslations();

  return (
    <div className="flex items-center space-x-2 flex-shrink-0">
      <button
        onClick={() => setLanguage('en')}
        aria-pressed={language === 'en'}
        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
          language === 'en' ? 'bg-sky-500 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
        }`}
      >
        EN
      </button>
      <button
        onClick={() => setLanguage('pt')}
        aria-pressed={language === 'pt'}
        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
          language === 'pt' ? 'bg-sky-500 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
        }`}
      >
        PT
      </button>
    </div>
  );
};

// Generate 30 sample weight records for Buddy
const buddyWeightRecords = [];
const startDate = new Date('2023-10-01');
for (let i = 0; i < 30; i++) {
    const newDate = new Date(startDate);
    newDate.setDate(startDate.getDate() + (i * 7)); // Add a record every 7 days
    buddyWeightRecords.push({
        id: i + 1,
        date: newDate.toISOString().split('T')[0],
        weight: parseFloat((30.5 + (Math.random() - 0.5) * 2).toFixed(1)),
    });
}


const AppContent: React.FC = () => {
  const { t } = useTranslations();
  const { showToast } = useToast();
  const [currentView, setCurrentView] = useState<View>('pets');
  const [selectedPetId, setSelectedPetId] = useState<number | null>(null);
  
  const [pets, setPets] = useState<Pet[]>([
    { 
      id: 1, 
      name: 'Buddy', 
      species: 'Dog', 
      breed: 'golden_retriever', 
      age: 60, // 5 years in months
      sex: 'Male',
      color: 'Golden',
      microchip: '981020017834789',
      imageUrl: 'https://picsum.photos/seed/buddy/200',
      weightRecords: buddyWeightRecords
    },
    { 
      id: 2, 
      name: 'Lucy', 
      species: 'Cat', 
      breed: 'siamese', 
      age: 36, // 3 years in months
      sex: 'Female',
      color: 'Cream',
      microchip: '981020017834790',
      imageUrl: 'https://picsum.photos/seed/lucy/200',
      weightRecords: [
        { id: 1, date: '2024-02-01', weight: 4.5 },
        { id: 2, date: '2024-03-01', weight: 4.6 },
        { id: 3, date: '2024-04-01', weight: 4.4 },
      ]
    },
  ]);

  const addPet = useCallback(async (pet: Omit<Pet, 'id' | 'weightRecords'>) => {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API call
    setPets(prevPets => [...prevPets, { ...pet, id: Date.now(), weightRecords: [] }]);
    showToast(t('toast.petAdded', { name: pet.name }));
  }, [showToast, t]);

  const updatePet = useCallback(async (petId: number, updatedData: Omit<Pet, 'id' | 'weightRecords' | 'age'> & { age: number }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    setPets(prevPets => prevPets.map(p =>
      p.id === petId
        ? { ...p, ...updatedData }
        : p
    ));
    showToast(t('toast.petUpdated', { name: updatedData.name }));
  }, [showToast, t]);

  const addWeightRecord = useCallback(async (petId: number, record: Omit<WeightRecord, 'id'>) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const petName = pets.find(p => p.id === petId)?.name || '';
    setPets(pets.map(p => 
      p.id === petId 
        ? { ...p, weightRecords: [...p.weightRecords, { ...record, id: Date.now() }].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()) } 
        : p
    ));
    showToast(t('toast.weightAdded', { name: petName }));
  }, [pets, showToast, t]);

  const updateWeightRecord = useCallback(async (petId: number, recordId: number, updatedData: { date: string, weight: number }) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const petName = pets.find(p => p.id === petId)?.name || '';
    setPets(pets.map(p => 
        p.id === petId 
            ? { 
                ...p, 
                weightRecords: p.weightRecords.map(r => 
                    r.id === recordId ? { ...r, ...updatedData } : r
                ).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            } 
            : p
    ));
    showToast(t('toast.weightUpdated', { name: petName }));
  }, [pets, showToast, t]);

  const deleteWeightRecord = useCallback(async (petId: number, recordId: number) => {
      await new Promise(resolve => setTimeout(resolve, 500));
      const petName = pets.find(p => p.id === petId)?.name || '';
      setPets(pets.map(p => 
          p.id === petId 
              ? { ...p, weightRecords: p.weightRecords.filter(r => r.id !== recordId) } 
              : p
      ));
      showToast(t('toast.weightDeleted', { name: petName }));
  }, [pets, showToast, t]);

  const handleSelectPet = (petId: number) => {
    setSelectedPetId(petId);
    setCurrentView('petDetail');
  };

  const handleBackToList = () => {
    setSelectedPetId(null);
    setCurrentView('pets');
  };

  const renderView = () => {
    const selectedPet = pets.find(p => p.id === selectedPetId);
    if (currentView === 'petDetail' && selectedPet) {
      return (
        <PetDetailView 
          pet={selectedPet} 
          onBack={handleBackToList}
          onUpdatePet={updatePet}
          onAddWeight={addWeightRecord}
          onUpdateWeight={updateWeightRecord}
          onDeleteWeight={deleteWeightRecord}
        />
      );
    }
    return <PetsView pets={pets} addPet={addPet} onSelectPet={handleSelectPet} />;
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-slate-200 p-4 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-2">
            <div className="flex items-center text-center sm:text-left">
              <span className="p-2 bg-sky-500 rounded-full mr-3 sm:mr-4 flex-shrink-0">
                <PetPawIcon className="w-6 h-6 text-white" />
              </span>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-slate-800">{t('appTitle')}</h1>
                <p className="text-xs sm:text-sm text-slate-500">{t('appTagline')}</p>
              </div>
            </div>
            <LanguageSwitcher />
        </header>
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => (
  <LanguageProvider>
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  </LanguageProvider>
);

export default App;